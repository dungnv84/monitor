# consul dev
# tror file hosts
42.117.246.30 env-dev.mykiot.vn
# link consul
http://env-dev.mykiot.vn/

# link thong tin server
https://docs.google.com/spreadsheets/d/1u18AJr6HTuELvyFqNg3uUJc4fjJkbbksQH0OabPLE6Q/edit#gid=1889051149

